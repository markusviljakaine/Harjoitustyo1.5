package com.example.harkkatyo;

public class Orange extends Lutemon {

    public Orange(String name, String color) {
        super(name, color, 8, 1, 0, 17, 17);
        image = R.drawable.orange;
    }
}

package com.example.harkkatyo;

import androidx.annotation.NonNull;

public class Black extends Lutemon {

    public Black(String name, String color) {
        super(name, color, 9, 0, 0, 16, 16);
        image = R.drawable.black;
    }

}
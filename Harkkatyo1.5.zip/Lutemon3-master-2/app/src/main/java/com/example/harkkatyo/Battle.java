package com.example.harkkatyo;

public class Battle {
}
